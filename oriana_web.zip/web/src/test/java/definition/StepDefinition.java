package definition;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.interactions.Actions;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.When;
import io.github.bonigarcia.wdm.WebDriverManager;
public class StepDefinition {
	WebDriver driver;
	@Given("Launch the browser")
	public void launch_the_browser() {
	    // Write code here that turns the phrase above into concrete actions
		WebDriverManager.edgedriver().setup();
		driver=new EdgeDriver();
		driver.manage().window().maximize();
		driver.get("https://www.oriana.com/");
	}

	@When("Login to oriana")
	public void login_to_oriana() throws InterruptedException {
		 
	    // Write code here that turns the phrase above into concrete actions
		
	    driver.findElement(By.xpath("//*[@id=\"authorizationlink\"]/a")).click();
	 
	   //Thread.sleep(3000);
	  
	   driver.findElement(By.xpath("//input[@name='login[username]']")).sendKeys("keerthusankara2721@gmail.com");
	   driver.findElement(By.xpath("//input[@name='login[password]']")).sendKeys("Keerthi@2721");
	   Thread.sleep(2000);
	  
	   driver.findElement(By.xpath("//*[@id=\"login-btn\"]/span")).click();
	   Thread.sleep(5000);
	   
	  driver.findElement(By.id("search")).click();
	   driver.findElement(By.id("search")).sendKeys("ring");
	  driver.findElement(By.cssSelector(".actions > .search")).click();
	  {
	      WebElement element = driver.findElement(By.cssSelector(".add_custom_wishlist_52938"));
	      Actions builder = new Actions(driver);
	      builder.moveToElement(element).perform();
	    }
	    driver.findElement(By.cssSelector(".add_custom_wishlist_52938")).click();
	    
	   //driver.get("https://www.oriana.com/customer/account/logout/");
	   Thread.sleep(5000);
	   driver.findElement(By.xpath("//*[@id=\"id1NNFxWqh\"]")).click();
		   
	}
	

	@When("Quit the browser")
	public void quit_the_browser() throws InterruptedException {
	    // Write code here that turns the phrase above into concrete actions
//		Thread.sleep(5000);
//		driver.quit();
	    
	}

}
