package runner;

/*public class Runner {


}*/
import io.cucumber.testng.AbstractTestNGCucumberTests;


import io.cucumber.testng.CucumberOptions;

@CucumberOptions(
        features = "C:\\Users\\a851301\\eclipse-workspace\\java\\web\\FeatureFiles\\data.feature"
        ,glue = {"definition"}
        ,plugin = {"com.aventstack.extentreports.cucumber.adapter.ExtentCucumberAdapter:"}
        ,monochrome = true
        ,publish = true
        )
public class Runner extends AbstractTestNGCucumberTests{

}
